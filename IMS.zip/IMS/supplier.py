
from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk
import sqlite3
from tkinter import messagebox
class supplierClass:
    def __init__(self,root):
        
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("Inventory Management System | Developed By Dharshan")
        self.root.config(bg="white")
        
        
        self.root.focus_force()

        #=====================================
        
        # ALL Variables======
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()
        
        self.var_sup_invoice=StringVar()
        self.var_name=StringVar()
    
        self.var_contact=StringVar()
       
  
        #=====searchFrame======
        
        
        #====option====
        
        
        lbl_search=Label(self.root,text="Invoice No.",bg="white",font=("goudy old style",15,))
        lbl_search.place(x=700,y=80)
     
        
        txt_search=Entry(self.root,textvariable=self.var_searchtxt,font=("gowdy old style",15),bg="lightyellow").place(x=800,y=80,width=160)

        btn_search=Button(self.root,text="Search",command=self.search,font=("gowdy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=980,y=79,width=100,height=28)

        #====title====
        
        
        title=Label(self.root,text="Supplier Details",font=("goudy old style",20,"bold"),bg="#0f4d7d",fg="white").place(x=50,y=10,width=1000,height=40)
      #====content======
        
        #===Row 1====
        
        lbl_supplier_invoice=Label(self.root,text="Invoice No.",font=("goudy old style",15),bg="white").place(x=50,y=80)
      
        txt_supplier_invoice=Entry(self.root,textvariable=self.var_sup_invoice,font=("goudy old style",15),bg="lightyellow").place(x=180,y=80,width=180)
        
        
            
        #===row 2=====
        

        lbl_name=Label(self.root,text="Name",font=("goudy old style",15),bg="white").place(x=50,y=120)
      
        txt_name=Entry(self.root,textvariable=self.var_name,font=("goudy old style",15),bg="lightyellow").place(x=180,y=120,width=180)
       
        
        #===row 3=====
        

        lbl_contact=Label(self.root,text="Contact",font=("goudy old style",15),bg="white").place(x=50,y=160)
      
        txt_contact=Entry(self.root,textvariable=self.var_contact,font=("goudy old style",15),bg="lightyellow").place(x=180,y=160,width=180)
       
     
            
        #===row 4=====
        

        lbl_desc=Label(self.root,text="Description",font=("goudy old style",15),bg="white").place(x=50,y=200)
       
        self.txt_desc=Text(self.root,font=("goudy old style",15),bg="lightyellow")
        self.txt_desc.place(x=180,y=200,width=470,height=120)
       
        #=====buttons========
        
        btn_add=Button(self.root,text="Save",command=self.add,font=("gowdy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=180,y=370,width=110,height=35)
        btn_update=Button(self.root,text="Update",command=self.update,font=("gowdy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=300,y=370,width=110,height=35)
        btn_delete=Button(self.root,text="Delete",command=self.delete,font=("gowdy old style",15),bg="#f44336",fg="white",cursor="hand2").place(x=420,y=370,width=110,height=35)
        btn_clear=Button(self.root,text="Clear",command=self.clear,font=("gowdy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=540,y=370,width=110,height=35)
        
        
        
     # ==== Employee Details ====

      # ==== Employee Details ====
        
        # Frame to hold the Treeview
        emp_frame = Frame(self.root, bd=3, relief=RIDGE)
        emp_frame.place(x=700, y=120, width=380, height=350)
        
        # Scrollbars for Treeview
        scroll_y = Scrollbar(emp_frame, orient=VERTICAL)
        scroll_x = Scrollbar(emp_frame, orient=HORIZONTAL)
        
        # Treeview widget
        self.supplierTable = ttk.Treeview(
            emp_frame,
            columns=("invoice", "name", "contact", "desc"),
            yscrollcommand=scroll_y.set,
            xscrollcommand=scroll_x.set
        )
        
        # ✅ Hide the default empty column (#0)
        self.supplierTable["show"] = "headings"
        
        # Place scrollbars
        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)
        
        # Configure scrollbars with Treeview
        scroll_x.config(command=self.supplierTable.xview)
        scroll_y.config(command=self.supplierTable.yview)
        
        # Define column headings
        self.supplierTable.heading("invoice", text="Invoice No.")
        self.supplierTable.heading("name", text="Name")
        self.supplierTable.heading("contact", text="Contact")
        self.supplierTable.heading("desc", text="Description")
        
        # Set column widths
        self.supplierTable.column("invoice", width=90)
        self.supplierTable.column("name", width=100)
        self.supplierTable.column("contact", width=100)
        self.supplierTable.column("desc", width=100)
        
        # Pack the Treeview
        self.supplierTable.pack(fill=BOTH, expand=1)
        
        # Bind click event to get data
        self.supplierTable.bind("<ButtonRelease-1>", self.get_data)
        
        # Populate the Treeview
        self.show()


#===================================================


    def add(self):
        try:
            if self.var_sup_invoice.get() == "":
                messagebox.showerror("Error", "Invoice must be required", parent=self.root)
                return
            else:
                con = sqlite3.connect(database=r'ims.db')
                cur = con.cursor()
    
                # Check if employee ID already exists
                cur.execute("SELECT * FROM supplier WHERE invoice= ?", (self.var_sup_invoice.get(),))
                row = cur.fetchone()
                if row is not None:
                    messagebox.showerror("Error", "Invoice No. is already assigned, try a different one", parent=self.root)
                else:
                    # Insert new employee data
                    cur.execute("""
                        INSERT INTO supplier(
                            invoice, name, contact, desc
                        ) VALUES (?, ?, ?, ?)
                    """, (
                        self.var_sup_invoice.get(),
                        self.var_name.get(),
                       self.var_contact.get(),
                       self.txt_desc.get('1.0', END),
                       
                    ))
                    con.commit()
                    messagebox.showinfo("Success", "Supplier Added successfully", parent=self.root)
                con.close()
                self.show()
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def show(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            cur.execute("Select * from supplier ")
            rows=cur.fetchall()
            self.supplierTable.delete(*self.supplierTable.get_children())
            for row in rows:
                self.supplierTable.insert('', END,values=row)
           
           
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
            
            

    def get_data(self,ev):
        f=self.supplierTable.focus()
        content=(self.supplierTable.item(f))
        
        row=content['values']
        
        self.var_sup_invoice.set(row[0])
        self.var_name.set(row[1])
        self.var_contact.set(row[2])
        self.txt_desc.delete('1.0', END)
        self.txt_desc.insert(END,row[3])
     


    def update(self):
        try:
            if self.var_sup_invoice.get() == "":
                messagebox.showerror("Error", "Invoice No. must be required", parent=self.root)
                return
            else:
                con = sqlite3.connect(database=r'ims.db')
                cur = con.cursor()
    
                # Check if invoice already exists
                cur.execute("SELECT * FROM supplier WHERE invoice = ?", (self.var_sup_invoice.get(),))
                row = cur.fetchone()
                if row is None:
                    messagebox.showerror("Error", "Invalid Invoice No.", parent=self.root)
                else:
                    # Update supplier data
                    cur.execute("""
                        UPDATE supplier SET 
                            name = ?, 
                            contact = ?, 
                            desc = ?
                        WHERE invoice = ?
                    """, (
                        self.var_name.get(),
                        self.var_contact.get(),
                        self.txt_desc.get('1.0', END).strip(),
                        self.var_sup_invoice.get()
                    ))
                    con.commit()
                    messagebox.showinfo("Success", "Supplier updated successfully", parent=self.root)
                con.close()
                self.show()
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)


    def delete(self):
        try:
            if self.var_sup_invoice.get() == "":
                messagebox.showerror("Error", "Invoice No. must be required", parent=self.root)
                return
            else:
                con = sqlite3.connect(database=r'ims.db')
                cur = con.cursor()
                
                cur.execute("SELECT * FROM supplier WHERE invoice = ?", (self.var_sup_invoice.get(),))
                row = cur.fetchone()
                if row ==None:
                    messagebox.showerror("Error", "Invalid Invoice No. ", parent=self.root)
                else:
                    op=messagebox.askyesno("Conform","Do u really want to delete?",parent=self.root)
                    if op==TRUE:
                        
                        cur.execute("delete from supplier where invoice=?",(self.var_sup_invoice.get(),))
                        con.commit()
                        messagebox.showinfo("Delete","Supplier deleted successfully",parent=self.root)
                      
                        self.clear()
                    
        
        
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

        
    def clear(self):
        
        self.var_sup_invoice.set("")
        self.var_name.set("")
        self.var_contact.set("")
        self.txt_desc.delete('1.0', END)
      
        self.var_searchtxt.set("")
        self.show()

    def search(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_searchtxt.get() == "":
                messagebox.showerror("Error", "Invoice No. should be required", parent=self.root)
                return
            else:
               
                cur.execute("SELECT * FROM supplier WHERE invoice = ?", (self.var_searchtxt.get(),))
                row = cur.fetchone()
    
                if row is not None:
                    self.supplierTable.delete(*self.supplierTable.get_children())
                    self.supplierTable.insert('', END, values=row)
                else:
                    messagebox.showerror("Error", "No record found", parent=self.root)
    
                con.close()
    
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

   

if __name__=="__main__":
    

    root=Tk()
    obj=supplierClass(root)
    root.mainloop()


